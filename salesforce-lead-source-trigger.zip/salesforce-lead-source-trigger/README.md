# Salesforce Lead Source Trigger

## Overview
Apex trigger that automatically sets the **Lead Source** field when a new Lead is created, based on the email domain:

| Email Domain | Lead Source |
|---|---|
| `gmail.com` | Personal |
| Any other domain | Business |
| No email provided | Unchanged |

## Project Structure
```
force-app/main/default/
├── triggers/
│   ├── LeadTrigger.trigger            # Thin trigger (delegates to handler)
│   └── LeadTrigger.trigger-meta.xml
└── classes/
    ├── LeadTriggerHandler.cls         # Business logic
    ├── LeadTriggerHandler.cls-meta.xml
    ├── LeadTriggerHandlerTest.cls     # Test class (5 test methods)
    └── LeadTriggerHandlerTest.cls-meta.xml
```

## Design Decisions
- **Thin trigger pattern** — Trigger contains no logic; all processing is in `LeadTriggerHandler` for testability and maintainability.
- **Bulk-safe** — Iterates over the full `Trigger.new` list with no SOQL or DML inside the loop.
- **Before-insert context** — Modifies fields in-place, avoiding unnecessary DML operations.
- **Case-insensitive** — Handles mixed-case domains like `GMAIL.COM` or `Gmail.Com`.
- **Null-safe** — Leads without an email address are skipped gracefully.
- **Constants** — Domain and source values are defined once for easy extension.

## Test Coverage
The test class includes **5 test methods**:
1. Gmail domain → Personal
2. Gmail domain (mixed case) → Personal
3. Non-gmail domain → Business
4. Null email → no change
5. Bulk insert of 200 records

Expected code coverage: **100%**

## Deployment

### Option A: Salesforce CLI (SFDX)
```bash
sf project deploy start --source-dir force-app --target-org <your-org-alias>
```

### Option B: Change Set
1. Copy the trigger and classes into your sandbox org via Developer Console.
2. Create an Outbound Change Set containing the trigger and both classes.
3. Upload and deploy to the target org.

## Extending This Solution
To add more personal domains (e.g., `yahoo.com`, `hotmail.com`), replace the single constant with a `Set<String>`:
```apex
private static final Set<String> PERSONAL_DOMAINS = new Set<String>{
    'gmail.com', 'yahoo.com', 'hotmail.com', 'outlook.com'
};
```
Then update the condition:
```apex
if (PERSONAL_DOMAINS.contains(domain)) { ... }
```
